This module provids the lettersearch method that takes two strings, one for a phrase and one for a set of letters to search within that phrase.  
