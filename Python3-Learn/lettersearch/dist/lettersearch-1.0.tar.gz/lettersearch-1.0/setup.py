from setuptools import setup

setup (
        name='lettersearch',
        version='1.0',
        description='Letter search tool',
        author='Russ Carroll',
        author_email="dev.ops.rc.1980@gmail.com",
        py_modules=['lettersearch']
)
